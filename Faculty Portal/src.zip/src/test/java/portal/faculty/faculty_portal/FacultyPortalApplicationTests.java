package portal.faculty.faculty_portal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FacultyPortalApplicationTests {

    @Test
    void contextLoads() {
    }

}
