package portal.faculty.faculty_portal.task;

import portal.faculty.faculty_portal.task.dto.TaskView;
import portal.faculty.faculty_portal.user.User;

public final class TaskMapper {
    private TaskMapper() {}

    public static TaskView toView(Task t) {
        return TaskView.builder()
                .id(t.getId())
                .title(t.getTitle())
                .description(t.getDescription())
                .dueAt(t.getDueAt())
                .status(t.getStatus().name())
                .priority(t.getPriority())
                .assignedTo(toMini(t.getAssignedTo()))
                .assignedBy(toMini(t.getAssignedBy()))
                .createdAt(t.getCreatedAt())
                .updatedAt(t.getUpdatedAt())
                .build();
    }

    private static TaskView.MiniUser toMini(User u) {
        return TaskView.MiniUser.builder()
                .id(u.getId())
                .name(u.getName())
                .email(u.getEmail())
                .role(u.getRole().name())
                .department(u.getDepartment())
                .build();
    }
}
