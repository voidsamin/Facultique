package portal.faculty.faculty_portal.task;

import lombok.RequiredArgsConstructor;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import portal.faculty.faculty_portal.task.dto.TaskCreateDto;
import portal.faculty.faculty_portal.task.dto.TaskUpdateStatusDto;
import portal.faculty.faculty_portal.task.dto.TaskView;
import portal.faculty.faculty_portal.user.Role;
import portal.faculty.faculty_portal.user.User;
import portal.faculty.faculty_portal.user.UserRepository;

import java.util.List;

import static portal.faculty.faculty_portal.task.TaskMapper.toView;

@RestController
@RequestMapping("/api/tasks")
@RequiredArgsConstructor
public class TaskController {

    private final TaskRepository tasks;
    private final UserRepository users;

    /** NEW: List tasks for the current user (FACULTY) or all (HOD).
     *  Optional query param ?status=ASSIGNED|IN_PROGRESS|DONE etc. */
    @GetMapping
    public List<TaskView> listForCurrent(Authentication auth,
                                         @RequestParam(required = false) String status) {
        User requester = (User) auth.getPrincipal();
        boolean isHod = requester.getRole() == Role.HOD;

        TaskStatus filter = null;
        if (status != null && !status.isBlank()) {
            try {
                filter = TaskStatus.valueOf(status);
            } catch (IllegalArgumentException ex) {
                throw new IllegalArgumentException("Invalid status: " + status);
            }
        }

        List<Task> result;
        if (isHod) {
            // HOD sees everything (or filter by status if provided)
            if (filter == null) {
                result = tasks.findAll();
            } else {
                result = tasks.findByStatus(filter);
            }
        } else {
            // Faculty sees only their own tasks
            if (filter == null) {
                result = tasks.findByAssignedTo(requester);
            } else {
                result = tasks.findByAssignedToAndStatus(requester, filter);
            }
        }
        return result.stream().map(TaskMapper::toView).toList();
    }
    /** HOD creates/assigns a task. assignedBy = current authenticated user */
    @PostMapping
    @PreAuthorize("hasAnyAuthority('HOD','ROLE_HOD')")
    public TaskView create(@RequestBody TaskCreateDto dto, Authentication auth) {
        User assigner = (User) auth.getPrincipal();
//        if (assigner.getRole() != Role.HOD) {
//            throw new AccessDeniedException("Only HOD can assign tasks");
//        }

        User assignee = users.findById(dto.getAssignedToUserId())
                .orElseThrow(() -> new IllegalArgumentException("Assignee not found"));

        Task t = Task.builder()
                .title(dto.getTitle())
                .description(dto.getDescription())
                .dueAt(dto.getDueAt())
                .priority(dto.getPriority() == null ? 3 : dto.getPriority())
                .status(TaskStatus.ASSIGNED)
                .assignedTo(assignee)
                .assignedBy(assigner)
                .build();

        return toView(tasks.save(t));
    }

    /** List tasks for a specific userId.
     *  HOD can view anyone. FACULTY can only view their own tasks. */
    @GetMapping("/by-user/{userId}")
    public List<TaskView> listByUser(@PathVariable Long userId,
                                     Authentication auth,
                                     @RequestParam(required = false) String status) {
        User requester = (User) auth.getPrincipal();
        boolean isHod = requester.getRole() == Role.HOD;

        if (!isHod && !requester.getId().equals(userId)) {
            throw new AccessDeniedException("You can only view your own tasks");
        }

        User target = users.findById(userId).orElseThrow();
        List<Task> result;
        if (status == null || status.isBlank()) {
            result = tasks.findByAssignedTo(target);
        } else {
            TaskStatus st = TaskStatus.valueOf(status);
            result = tasks.findByAssignedToAndStatus(target, st);
        }

        return result.stream().map(TaskMapper::toView).toList();
    }

    /** NEW: Fetch a single task by id (auth required) */
    @GetMapping("/{taskId}")
    public TaskView getOne(@PathVariable Long taskId, Authentication auth) {
        User requester = (User) auth.getPrincipal();
        Task t = tasks.findById(taskId).orElseThrow();

        boolean isHod = requester.getRole() == Role.HOD;
        boolean isAssignee = t.getAssignedTo().getId().equals(requester.getId());
        boolean isAssigner = t.getAssignedBy() != null && t.getAssignedBy().getId().equals(requester.getId());

        if (!isHod && !isAssignee && !isAssigner) {
            throw new AccessDeniedException("Not allowed to view this task");
        }

        return toView(t);
    }

    /** Update status. Allowed for assignee or HOD. */
    @PatchMapping("/{taskId}/status")
    public TaskView updateStatus(@PathVariable Long taskId,
                                 @RequestBody TaskUpdateStatusDto body,
                                 Authentication auth) {
        User requester = (User) auth.getPrincipal();
        Task t = tasks.findById(taskId).orElseThrow();

        boolean isHod = requester.getRole() == Role.HOD;
        boolean isAssignee = t.getAssignedTo().getId().equals(requester.getId());
        if (!isHod && !isAssignee) {
            throw new AccessDeniedException("Only assignee or HOD may update task status");
        }

        t.setStatus(TaskStatus.valueOf(body.getStatus()));
        return toView(tasks.save(t));
    }
}
