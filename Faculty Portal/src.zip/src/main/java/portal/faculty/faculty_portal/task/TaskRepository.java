package portal.faculty.faculty_portal.task;

import org.springframework.data.jpa.repository.JpaRepository;
import portal.faculty.faculty_portal.user.User;

import java.time.Instant;
import java.util.List;

public interface TaskRepository extends JpaRepository<Task, Long> {
    List<Task> findByAssignedTo(User user);
    List<Task> findByAssignedToAndStatus(User user, TaskStatus status);
    List<Task> findByDueAtBeforeAndStatusNot(Instant cutoff, TaskStatus status);
    List<Task> findByStatus(TaskStatus status);
}
