package portal.faculty.faculty_portal.task;

public enum ReviewDecision {
    PENDING,
    APPROVED,
    REJECTED
}
