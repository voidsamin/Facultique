package portal.faculty.faculty_portal.task;

public enum TaskStatus {
    ASSIGNED, IN_PROGRESS, SUBMITTED, OVERDUE, CLOSED,COMPLETED
}
