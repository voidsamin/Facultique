package portal.faculty.faculty_portal;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import portal.faculty.faculty_portal.user.*;



@Component
@Profile("!test")
@RequiredArgsConstructor
public class DataLoader implements CommandLineRunner {
    private final UserRepository users;
    private final PasswordEncoder encoder;

    @Override public void run(String... args) {
        if (users.count() == 3) {
            users.save(User.builder()
                    .name("Head of Dept1")
                    .email("hod@ftms.local1")
                    .password(encoder.encode("password"))
                    .role(Role.HOD)
                    .department("CSE")
                    .enabled(true)
                    .build());
        }
    }
}
