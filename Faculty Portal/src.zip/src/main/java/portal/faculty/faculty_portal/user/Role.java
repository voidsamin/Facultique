package portal.faculty.faculty_portal.user;

public enum Role {
    FACULTY, HOD, ADMIN, IT
}
